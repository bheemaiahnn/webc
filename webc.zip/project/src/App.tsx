import React, { useState } from 'react';
import { 
  Cloud, 
  Server, 
  Database, 
  HardDrive, 
  Shield, 
  Zap, 
  Users, 
  Globe, 
  Menu, 
  X, 
  Check,
  ArrowRight,
  Play,
  Monitor,
  Lock,
  Layers,
  Network,
  Cpu
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activePricing, setActivePricing] = useState('monthly');

  const services = [
    {
      icon: <Server className="w-8 h-8" />,
      title: "Cloud Server / Cloud Instance",
      description: "Scalable virtual machines with SSD storage, starting at $4/month",
      features: ["1-Click Apps", "Auto Backups", "Monitoring", "Load Balancers"]
    },
    {
      icon: <Layers className="w-8 h-8" />,
      title: "Kubernetes",
      description: "Managed Kubernetes clusters with automated scaling and updates",
      features: ["Auto-scaling", "1-Click Deploy", "Monitoring", "Load Balancing"]
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "Databases",
      description: "Fully managed databases with automated backups and scaling",
      features: ["MySQL", "PostgreSQL", "Redis", "MongoDB"]
    },
    {
      icon: <HardDrive className="w-8 h-8" />,
      title: "Storage",
      description: "Block and object storage solutions with 99.99% uptime",
      features: ["Block Storage", "Spaces Object Storage", "Backup", "CDN"]
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: "Private Cloud",
      description: "Dedicated infrastructure with complete isolation and control",
      features: ["Dedicated Hardware", "Custom Network", "Enhanced Security", "24/7 Support"]
    },
    {
      icon: <Network className="w-8 h-8" />,
      title: "Hybrid Cloud",
      description: "Seamlessly connect on-premises and cloud infrastructure",
      features: ["Unified Management", "Data Sync", "Flexible Scaling", "Secure Connectivity"]
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Public Cloud",
      description: "Multi-tenant cloud services with global reach and scalability",
      features: ["Global CDN", "Auto-scaling", "Pay-as-you-go", "99.9% Uptime"]
    },
    {
      icon: <Cpu className="w-8 h-8" />,
      title: "Bare Metal",
      description: "Dedicated physical servers with no virtualization overhead",
      features: ["Dedicated Hardware", "Maximum Performance", "Custom Configuration", "Direct Hardware Access"]
    }
  ];

  const pricingPlans = [
    {
      name: "Starter",
      monthly: 4,
      yearly: 40,
      description: "Perfect for small projects and development",
      features: [
        "1 vCPU",
        "1 GB RAM",
        "25 GB SSD",
        "1 TB Transfer",
        "Basic Support"
      ]
    },
    {
      name: "Professional",
      monthly: 18,
      yearly: 180,
      description: "Ideal for production applications",
      features: [
        "2 vCPUs",
        "4 GB RAM",
        "80 GB SSD",
        "4 TB Transfer",
        "Priority Support",
        "Monitoring & Alerts"
      ],
      popular: true
    },
    {
      name: "Business",
      monthly: 48,
      yearly: 480,
      description: "Built for high-performance workloads",
      features: [
        "4 vCPUs",
        "8 GB RAM",
        "160 GB SSD",
        "5 TB Transfer",
        "24/7 Support",
        "Advanced Monitoring",
        "Dedicated Support"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Cloud className="w-8 h-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">Theworklabs Cloud</span>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#products" className="text-gray-700 hover:text-blue-600 transition-colors">Products</a>
              <a href="#pricing" className="text-gray-700 hover:text-blue-600 transition-colors">Pricing</a>
              <a href="#docs" className="text-gray-700 hover:text-blue-600 transition-colors">Docs</a>
              <a href="#support" className="text-gray-700 hover:text-blue-600 transition-colors">Support</a>
            </nav>

            <div className="hidden md:flex items-center space-x-4">
              <button className="text-gray-700 hover:text-blue-600 transition-colors">Sign In</button>
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Get Started
              </button>
            </div>

            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-4 py-4 space-y-4">
              <a href="#products" className="block text-gray-700 hover:text-blue-600">Products</a>
              <a href="#pricing" className="block text-gray-700 hover:text-blue-600">Pricing</a>
              <a href="#docs" className="block text-gray-700 hover:text-blue-600">Docs</a>
              <a href="#support" className="block text-gray-700 hover:text-blue-600">Support</a>
              <div className="flex flex-col space-y-2 pt-4 border-t">
                <button className="text-left text-gray-700 hover:text-blue-600">Sign In</button>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Get Started
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              The cloud platform
              <span className="text-blue-600"> built for developers</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Deploy, manage, and scale cloud applications faster and more efficiently. 
              From simple droplets to complex hybrid architectures.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <button className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center">
                Start Building <ArrowRight className="ml-2 w-5 h-5" />
              </button>
              <button className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-50 transition-colors flex items-center justify-center">
                <Play className="mr-2 w-5 h-5" /> Watch Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="products" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything you need to build modern applications
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From virtual machines to managed databases, we provide the building blocks 
              for your cloud infrastructure.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-xl border border-gray-200 hover:border-blue-200 hover:shadow-lg transition-all duration-300 group">
                <div className="text-blue-600 mb-4 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-sm text-gray-500">
                      <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why developers choose Theworklabs Cloud
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Lightning Fast</h3>
              <p className="text-gray-600">Deploy in seconds with our optimized infrastructure and global network.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Enterprise Security</h3>
              <p className="text-gray-600">Bank-level security with encryption at rest and in transit.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">24/7 Support</h3>
              <p className="text-gray-600">Get help when you need it with our expert support team.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Simple, transparent pricing
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Choose the plan that fits your needs. Scale up or down anytime.
            </p>
            
            <div className="flex justify-center mb-8">
              <div className="bg-gray-100 p-1 rounded-lg">
                <button
                  className={`px-4 py-2 rounded-md transition-colors ${
                    activePricing === 'monthly' 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  onClick={() => setActivePricing('monthly')}
                >
                  Monthly
                </button>
                <button
                  className={`px-4 py-2 rounded-md transition-colors ${
                    activePricing === 'yearly' 
                      ? 'bg-white text-gray-900 shadow-sm' 
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                  onClick={() => setActivePricing('yearly')}
                >
                  Yearly <span className="text-green-600 text-sm ml-1">(Save 17%)</span>
                </button>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <div key={index} className={`bg-white rounded-xl border-2 p-8 relative ${
                plan.popular 
                  ? 'border-blue-500 shadow-xl scale-105' 
                  : 'border-gray-200 hover:border-blue-200 hover:shadow-lg'
              } transition-all duration-300`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-6">{plan.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-gray-900">
                      ${activePricing === 'monthly' ? plan.monthly : plan.yearly}
                    </span>
                    <span className="text-gray-600">
                      /{activePricing === 'monthly' ? 'mo' : 'yr'}
                    </span>
                  </div>

                  <button className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors ${
                    plan.popular
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                  }`}>
                    Get Started
                  </button>
                </div>

                <ul className="mt-8 space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to get started?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of developers who trust Theworklabs Cloud for their infrastructure needs.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors">
              Start Free Trial
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors">
              Contact Sales
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Cloud className="w-8 h-8 text-blue-400" />
                <span className="text-xl font-bold">Theworklabs Cloud</span>
              </div>
              <p className="text-gray-400 mb-4">
                The cloud platform built for developers by developers.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Products</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Cloud Servers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Kubernetes</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Databases</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Storage</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Private Cloud</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Hybrid Cloud</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Bare Metal</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Legal</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Theworklabs Cloud. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;